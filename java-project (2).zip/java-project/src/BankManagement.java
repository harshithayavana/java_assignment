
import java.util.Scanner;

public class BankManagement {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double balance = 1000.00;
        int choice;
        double amount;

        System.out.println("===== WELCOME TO BANK MANAGEMENT SYSTEM =====");

        do {
            System.out.println("\n1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");

            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter deposit amount: ");
                    amount = sc.nextDouble();

                    if (amount > 0) {
                        balance = balance + amount;
                        System.out.println("Amount deposited successfully!");
                        System.out.println("Updated Balance: Rs. " + balance);
                    } else {
                        System.out.println("Invalid deposit amount!");
                    }
                    break;

                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    amount = sc.nextDouble();

                    if (amount > 0 && amount <= balance) {
                        balance = balance - amount;
                        System.out.println("Withdrawal successful!");
                        System.out.println("Remaining Balance: Rs. " + balance);
                    } else {
                        System.out.println("Insufficient balance or invalid amount!");
                    }
                    break;

                case 3:
                    System.out.println("Your Current Balance: Rs. " + balance);
                    break;

                case 4:
                    System.out.println("Thank you for using our bank!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }

        } while (choice != 4);

        sc.close();
    }
}
